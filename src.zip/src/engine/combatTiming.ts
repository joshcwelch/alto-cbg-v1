export const COMBAT_TIMING = {
  attackWindup: 180,
  impactPause: 120,
  damageFX: 250,
  deathFX: 450,
  resolveBuffer: 100,
};
