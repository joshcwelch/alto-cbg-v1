export default function Board3D() {
  // 3D board elements are currently handled in 2D; keep this placeholder
  // to maintain scene ordering for hands and future battlefield effects.
  return null;
}
