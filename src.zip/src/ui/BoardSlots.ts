export type BoardPoint = {
  x: number;
  y: number;
};

export const BoardSlots = {
  HeroTop: { x: -20, y: 50 },
  HeroBottom: { x: -20, y: 640 },
  ManaBar: { x: 120, y: 740 },
  EndTurn: { x: 1062, y: 445 },
  Hand: { x: 348, y: 785 },
  EnemyHand: { x: 438, y: -285 },
  BoardCenter: { x: 768, y: 512 },
  AbilityFrame: { x: 1211, y: 700 },
  Graveyard: { x: 78, y: 475 },
  EnemyAbilityFrame: { x: 1211, y: 160 },
  PlayerDeckCount: { x: 250, y: 830 },
  EnemyDeckCount: { x: 260, y: 180 },
} as const satisfies Record<string, BoardPoint>;
