export const BOARD_WIDTH = 1536;
export const BOARD_HEIGHT = 1024;
