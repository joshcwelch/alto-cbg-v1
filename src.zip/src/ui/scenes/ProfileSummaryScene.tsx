import PlaceholderScene from "./PlaceholderScene";

const ProfileSummaryScene = () => {
  return <PlaceholderScene title="Profile Summary" />;
};

export default ProfileSummaryScene;
