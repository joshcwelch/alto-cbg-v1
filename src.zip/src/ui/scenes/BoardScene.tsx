import PlaceholderScene from "./PlaceholderScene";

const BoardScene = () => {
  return <PlaceholderScene title="Board" />;
};

export default BoardScene;
