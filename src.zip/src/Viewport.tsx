import GameRoot from "./GameRoot";

const Viewport = () => {
  return (
    <div className="viewport">
      <GameRoot />
    </div>
  );
};

export default Viewport;
