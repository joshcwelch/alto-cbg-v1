import "./App.css";
import AppRouter from "./ui/AppRouter";

export default function App() {
  return (
    <div className="app-shell">
      <AppRouter />
    </div>
  );
}
