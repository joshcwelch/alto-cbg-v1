import AppShell from "./ui/shell/AppShell";
import "./ui/styles/ui.css";

const App = () => {
  return <AppShell />;
};

export default App;
