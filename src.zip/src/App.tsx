import "./App.css";
import Board from "./ui/Board";

export default function App() {
  return (
    <div className="app-shell">
      <Board />
    </div>
  );
}
