import Viewport from "./Viewport";

const App = () => {
  return <Viewport />;
};

export default App;
